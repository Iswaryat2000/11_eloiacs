<?php
// Simulated database update (Replace with actual database update)
if (isset($_POST['emp_id'])) {
    $emp_id = $_POST['emp_id'];

    // Simulated success (Replace with actual database update logic)
    $success = true;

    if ($success) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
