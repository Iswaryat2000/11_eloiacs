<!DOCTYPE html>
<html>
<head>
    
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>All Project Counting Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/b272402e67.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/dashboard_pro.css">
    <link rel="stylesheet" href="../css/styless.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    </head>
<body>
    <div class="contain1">
    <button><a href="newreport.php">ALL </a></button>
    <button><a href="newall.php">DEPARTMENT</a></button>
    <button><a href="newallemp.php">EMP INDIVIDUAL</a></button>
    <button><a href="newallourbarch.php">BATCH</a></button>
    <button><a href="newallpro.php">PROJECT</a></button>
</body>

    <style>
        a{text-decoration:none;}
        h1 {
            background-color: #d1991b;
            color: white;
            padding: 10px;
            text-align: center;
        }
        
        table {
            width: 80%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }
        
        th {
            background-color: #d1991b;
            color: white;
        }
        
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        
        tr:hover {
            background-color: #ddd;
        }
        .contain1{
        margin-top:7%;
        }
        button{margin-bottom:2%;}
    </style>
</head>
<body>
    
    <h1>All Project Counting Report</h1>



<?php
include "../connection.php";
include_once '../includes/header.php';
$sqlReceivedPages = "SELECT DEPARTMENT, SUM(CASE WHEN STATUS != 'completed' THEN RECEIVEDPAGES ELSE 0 END) as totalReceivedPages FROM projects GROUP BY DEPARTMENT";


$resultReceivedPages = $conn->query($sqlReceivedPages);


$sqlCompletedValue = "
    SELECT p.DEPARTMENT, 
    SUM(CASE WHEN p.STATUS != 'completed' THEN n.completed ELSE 0 END) as totalcompleted 
    FROM projects p
    LEFT JOIN new n ON p.PROJECTID = n.projectid
    GROUP BY n.department";


$resultCompletedValue = $conn->query($sqlCompletedValue);

if (!$resultReceivedPages || !$resultCompletedValue) {
    echo "Error: " . $conn->error;
} else {
    echo "<table border='1'>";
    echo "<tr><th>Department</th><th>Total Received Pages</th><th>Total Completed Value</th><th>Total Pending Value</th></tr>";

    while ($rowReceivedPages = $resultReceivedPages->fetch_assoc()) {
        $department = $rowReceivedPages['DEPARTMENT'];
        $totalReceivedPages = $rowReceivedPages['totalReceivedPages'];

        // Find the corresponding row in the completed value results
        $totalCompletedValue = 0; // Default value if not found
        while ($rowCompletedValue = $resultCompletedValue->fetch_assoc()) {
            if ($rowCompletedValue['DEPARTMENT'] === $department) {
                $totalCompletedValue = $rowCompletedValue['totalcompleted'];
                break;
            }
        }
        
        $totalpendingValue = $totalReceivedPages - $totalCompletedValue;
        
        echo "<tr><td>$department</td><td>$totalReceivedPages</td><td>$totalCompletedValue</td><td>$totalpendingValue</td></tr>";

        // Reset the pointer of the completed value results to the beginning
        $resultCompletedValue->data_seek(0);
    }

    echo "</table>";
}
$conn->close();

?>
</div>

</body>
</html>
