

<footer class="footer_dark">
    <div class="bottom_footer bg-dark">
        	<div class="row align-items-center">
            	<div class="col-md-12">
                	<p class="copyright m-md-0 text-center">&copy; Copyright <?php echo date("Y");?> All rights reserved by Eloiacs.</p>
                </div>
            </div>
    </div>
 </footer>